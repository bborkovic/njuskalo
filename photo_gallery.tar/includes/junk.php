<?php 

class Junk {
	
}

?>