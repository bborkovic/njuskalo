<?php 

// Database Constants
defined("DB_SERVER") ? null : define("DB_SERVER", "127.0.0.1");
defined("DB_USER") ? null : define("DB_USER", "photo_gallery");
defined("DB_PASS") ? null : define("DB_PASS", "photo_gallery");
defined("DB_NAME") ? null : define("DB_NAME", "photo_gallery");


?>