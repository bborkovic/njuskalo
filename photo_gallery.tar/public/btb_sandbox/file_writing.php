<?php  

	require_once('../../includes/initialize.php');

	log_action('action', 'poruka ....');
?>


