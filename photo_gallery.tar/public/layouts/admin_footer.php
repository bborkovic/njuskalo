	    <div class="panel-footer">Copyright bla, bla, ..</div>
	  </div>
	</div>

</body>
</html>